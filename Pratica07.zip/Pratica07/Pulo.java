
public interface Pulo
{
    public void pular();
}
