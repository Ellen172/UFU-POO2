public class Main
{
    public static void main(String args[]) throws InterruptedException{
        
        
        System.out.println("\n----------------------------------");
        System.out.println("Iniciando..\n");
        Painel p = new Painel();
        p.jogar(p);
    
    }
}
