
public abstract class Game
{    
    public abstract Personagem createPersonagem(int x, int y);
    public abstract Inimigo createInimigo(int x, int y);
}
