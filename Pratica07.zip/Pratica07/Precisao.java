
public class Precisao extends Poder
{
    public Precisao(Ataque ataque){
        super(ataque);
        setValor(5);
        setNome("veneno");
    }
}
