
public class CorridaMedia extends Corrida
{
    public CorridaMedia(){
        super(3);
    }
    
    public void correr(){
        System.out.println("Personagem correu medio");
    }
}
