
public class Alcance extends Poder
{
    public Alcance(Ataque ataque){
        super(ataque);
        setValor(5);
        setNome("alcance");
    }
}
