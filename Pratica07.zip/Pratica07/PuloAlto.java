
public class PuloAlto implements Pulo
{
    public void pular(){
        System.out.println("Personagem pulou alto");
    }
}
