
public class Veneno extends Poder
{
    public Veneno(Ataque ataque){
        super(ataque);
        setValor(5);
        setNome("veneno");
    }
}
