
public class FlechaFogo extends Poder
{
    public FlechaFogo(Ataque ataque){
        super(ataque);
        setValor(2);
        setNome("flecha com fogo");
    }
}
