
public class CorridaDevagar extends Corrida
{
    public CorridaDevagar(){
        super(1);
    }
            
    public void correr(){
        System.out.println("Personagem correu devagar");
    }

}
