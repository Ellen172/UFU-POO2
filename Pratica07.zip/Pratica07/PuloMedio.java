
public class PuloMedio implements Pulo
{
    public void pular(){
        System.out.println("Personagem pulou medio");
    }
}
