
public class Espada extends Ataque
{
    public Espada(){
        setValor(3);
        setNome("espada");
    }
}
