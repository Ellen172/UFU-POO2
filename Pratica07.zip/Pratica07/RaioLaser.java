
public class RaioLaser extends Ataque
{
    public RaioLaser(){
        setValor(5);
        setNome("raio laser");
    }
}
