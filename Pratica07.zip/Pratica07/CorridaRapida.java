
public class CorridaRapida extends Corrida
{
    public CorridaRapida(){
        super(5);
    }
    
    public void correr(){
        System.out.println("Personagem correu rápido");
    }
}
