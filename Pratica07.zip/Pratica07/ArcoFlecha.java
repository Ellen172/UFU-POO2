
public class ArcoFlecha extends Ataque
{
    public ArcoFlecha(){
        setValor(2);
        setNome("arco e flecha");
    }
}
