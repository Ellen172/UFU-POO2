
public class PuloBaixo implements Pulo
{
    public void pular(){
        System.out.println("Personamge pulou baixo");
    }
}
