
public class Porrete extends Ataque
{
    public Porrete(){
        setValor(5);
        setNome("porrete");
    }
}
