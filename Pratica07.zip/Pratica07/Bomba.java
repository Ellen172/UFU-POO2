

public class Bomba extends Ataque
{
    public Bomba(){
        setValor(10);
        setNome("bomba");
    }
}
