public interface Correr 
{
    public void correr();
}