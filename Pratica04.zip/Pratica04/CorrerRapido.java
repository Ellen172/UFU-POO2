
public class CorrerRapido implements Correr
{
    public void correr(){
        System.out.println("Correr Rapido");
    }
}
