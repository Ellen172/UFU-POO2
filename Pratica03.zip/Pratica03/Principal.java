
public class Principal
{
    public static void main(String args[])throws InterruptedException {
        System.out.println("Iniciando..");
        Painel p = new Painel();
        p.jogar(p);
    }
}
