
public class CorrerMedio implements Correr
{
    public void correr(){
        System.out.println("Correr Medio");
    }
}
