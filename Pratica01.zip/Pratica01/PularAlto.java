
public class PularAlto implements Pular
{
    public void pular(){
        System.out.println("Pulo Alto");
    }
}
