
public class Personagem1 extends Personagem
{
    public Personagem1(){
         setPular(new PularMedio());
         setCorrer(new CorrerMedio());
         setAtacar(new AtacarForte());
    }
}
