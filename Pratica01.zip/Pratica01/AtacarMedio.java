
public class AtacarMedio implements Atacar
{
    public void atacar(){
        System.out.println("Ataque Medio");
    }
}
