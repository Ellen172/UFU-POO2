
public class Personagem3 extends Personagem
{
    public Personagem3(){
        setPular(new PularBaixo());
        setCorrer(new CorrerRapido());
        setAtacar(new AtacarForte());
    }
}
