
public class Personagem2 extends Personagem
{
    public Personagem2(){
        setPular(new PularAlto());
        setCorrer(new CorrerRapido());
        setAtacar(new AtacarMedio());
    }
}
