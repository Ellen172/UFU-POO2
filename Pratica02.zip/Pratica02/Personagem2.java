
public class Personagem2 extends Personagem
{
    public Personagem2(){
        super(new PularAlto(), new CorrerRapido(), new AtacarMedio());
    }
}
