
public class Personagem1 extends Personagem
{
    public Personagem1(){
        super(new PularMedio(), new CorrerMedio(), new AtacarForte());
    }
}
