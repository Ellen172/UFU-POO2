
public class CorrerDevagar implements Correr
{
    public void correr(){
        System.out.println("Correr Devagar");
    }
}
