
public class PularMedio implements Pular
{
    public void pular(){
        System.out.println("Pulo Medio");
    }
}
