
public class Personagem3 extends Personagem
{
    public Personagem3(){
        super(new PularBaixo(), new CorrerRapido(), new AtacarForte());
    }
}
