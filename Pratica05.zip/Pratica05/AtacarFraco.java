
public class AtacarFraco implements Atacar
{
    public void atacar(){
        
        System.out.println("Ataque Fraco");
    }
}
