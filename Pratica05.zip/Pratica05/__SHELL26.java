
public class __SHELL26 extends bluej.runtime.Shell {
public static void run() throws Throwable {

java.lang.String[] __bluej_param0 = { };
Principal.main(__bluej_param0);

}}
