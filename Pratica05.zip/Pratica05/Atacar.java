public interface Atacar
{    
    public void atacar();
}