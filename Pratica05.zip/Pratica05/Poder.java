
public abstract class Poder extends Personagem
{    
    Personagem persona;
    
    public Poder(Personagem persona){
        this.persona = persona;
    }
}
