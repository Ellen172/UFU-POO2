public interface Pular
{
    public void pular();
}