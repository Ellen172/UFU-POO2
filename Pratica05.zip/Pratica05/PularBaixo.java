
public class PularBaixo implements Pular
{
    public void pular(){
        System.out.println("Pulo Baixo");
    }
}
