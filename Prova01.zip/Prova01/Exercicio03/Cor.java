
public class Cor extends Decorador
{
    public Cor(Objeto obj){
        super(obj);
        setDescricao("Cor");
    }
}
