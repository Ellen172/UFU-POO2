

public class Sombra extends Decorador
{
    public Sombra(Objeto obj){
        super(obj);
        setDescricao("Sombra");
    }
}
