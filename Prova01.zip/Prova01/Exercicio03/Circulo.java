
public class Circulo extends Objeto
{
    Circulo(){
        this.setDescricao("Circulo");
    }
}
